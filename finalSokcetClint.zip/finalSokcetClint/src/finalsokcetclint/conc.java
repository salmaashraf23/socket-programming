
package finalsokcetclint;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class conc {
  private  String pass="";
private String user="root";
private String add="jdbc:mysql://localhost/client";


 Connection  getCon() throws SQLException{
       return DriverManager.getConnection(add,user,pass);
      

    
}

}
    

